public abstract class SortAlgorithm {

    public  abstract  int[] sortMet(int[] a);
}
